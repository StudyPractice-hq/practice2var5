import sqlite3
from typing import List, Tuple, Optional
from datetime import datetime

DB_NAME = 'library.db'

def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS books (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            author TEXT NOT NULL,
            genre TEXT,
            price REAL NOT NULL,
            quantity INTEGER NOT NULL DEFAULT 1,
            description TEXT,
            pdf_path TEXT NOT NULL
        )
    ''')
    c.execute('''
        CREATE TABLE IF NOT EXISTS sales (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            book_id INTEGER NOT NULL,
            sale_date TEXT NOT NULL,
            price REAL NOT NULL,
            FOREIGN KEY(book_id) REFERENCES books(id)
        )
    ''')
    conn.commit()
    conn.close()

def add_book(title: str, author: str, genre: str, price: float, quantity: int, description: str, pdf_path: str):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''
        INSERT INTO books (title, author, genre, price, quantity, description, pdf_path)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (title, author, genre, price, quantity, description, pdf_path))
    conn.commit()
    conn.close()

def update_book(book_id: int, title: str, author: str, genre: str, price: float, quantity: int, description: str, pdf_path: str):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''
        UPDATE books SET title=?, author=?, genre=?, price=?, quantity=?, description=?, pdf_path=? WHERE id=?
    ''', (title, author, genre, price, quantity, description, pdf_path, book_id))
    conn.commit()
    conn.close()

def get_books(filter_title: Optional[str] = None, filter_author: Optional[str] = None, filter_genre: Optional[str] = None, filter_quantity: Optional[int] = None, filter_price: Optional[float] = None) -> List[Tuple]:
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    query = 'SELECT * FROM books WHERE 1=1'
    params = []
    if filter_title:
        query += ' AND title LIKE ?'
        params.append(f'%{filter_title}%')
    if filter_author:
        query += ' AND author LIKE ?'
        params.append(f'%{filter_author}%')
    if filter_genre:
        query += ' AND genre LIKE ?'
        params.append(f'%{filter_genre}%')
    if filter_quantity is not None:
        query += ' AND quantity = ?'
        params.append(filter_quantity)
    if filter_price is not None:
        query += ' AND price = ?'
        params.append(filter_price)
    c.execute(query, params)
    books = c.fetchall()
    conn.close()
    return books

def delete_book(book_id: int):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('DELETE FROM books WHERE id = ?', (book_id,))
    conn.commit()
    conn.close()

def sell_book(book_id: int, price: float):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''
        INSERT INTO sales (book_id, sale_date, price)
        VALUES (?, ?, ?)
    ''', (book_id, datetime.now().isoformat(), price))
    c.execute('UPDATE books SET quantity = quantity - 1 WHERE id = ? AND quantity > 0', (book_id,))
    conn.commit()
    conn.close()

def get_sales_stats():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''
        SELECT b.title, COUNT(s.id) as sales_count, SUM(s.price) as total_revenue, b.quantity
        FROM books b LEFT JOIN sales s ON b.id = s.book_id
        GROUP BY b.id
    ''')
    stats = c.fetchall()
    conn.close()
    return stats

def get_sales_by_date():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''
        SELECT sale_date, SUM(price) FROM sales GROUP BY sale_date
    ''')
    data = c.fetchall()
    conn.close()
    return data

def get_business_metrics():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('SELECT SUM(price) FROM sales')
    total_revenue = c.fetchone()[0] or 0
    c.execute('SELECT COUNT(*) FROM sales')
    total_sales = c.fetchone()[0] or 0
    c.execute('SELECT AVG(price) FROM sales')
    avg_check = c.fetchone()[0] or 0
    c.execute('''SELECT b.title, COUNT(s.id) as sales_count FROM books b JOIN sales s ON b.id = s.book_id GROUP BY b.id ORDER BY sales_count DESC LIMIT 5''')
    top_books = c.fetchall()
    conn.close()
    return {
        'total_revenue': total_revenue,
        'total_sales': total_sales,
        'avg_check': avg_check,
        'top_books': top_books
    } 