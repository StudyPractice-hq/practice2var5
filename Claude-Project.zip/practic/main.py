from PyQt5.QtWidgets import QApplication
import sys
from db import init_db
from ui_main import MainWindow

if __name__ == '__main__':
    init_db()
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_()) 