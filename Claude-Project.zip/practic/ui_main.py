import os
import shutil
from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTableWidget, QTableWidgetItem,
    QLineEdit, QLabel, QFileDialog, QDialog, QTextEdit, QFormLayout, QDoubleSpinBox, QMessageBox, QTabWidget, QScrollArea
)
from PyQt5.QtCore import Qt
import subprocess
from db import get_books, add_book, delete_book, sell_book, get_sales_stats, get_sales_by_date, update_book
import fitz  # PyMuPDF
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from PyQt5.QtWidgets import QHeaderView
from openpyxl import Workbook

PDF_DIR = 'pdfs'

class PDFViewer(QDialog):
    def __init__(self, pdf_path, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Просмотр PDF')
        self.resize(800, 900)
        layout = QVBoxLayout(self)
        self.pdf_path = pdf_path
        self.doc = fitz.open(pdf_path)
        self.current_page = 0
        self.page_label = QLabel()
        self.scroll = QScrollArea()
        self.canvas = QLabel()
        self.canvas.setAlignment(Qt.AlignCenter)
        self.scroll.setWidgetResizable(True)
        self.scroll.setWidget(self.canvas)
        nav_layout = QHBoxLayout()
        self.prev_btn = QPushButton('Назад')
        self.next_btn = QPushButton('Вперёд')
        self.prev_btn.clicked.connect(self.prev_page)
        self.next_btn.clicked.connect(self.next_page)
        nav_layout.addWidget(self.prev_btn)
        nav_layout.addWidget(self.page_label)
        nav_layout.addWidget(self.next_btn)
        layout.addLayout(nav_layout)
        layout.addWidget(self.scroll)
        self.show_page()

    def show_page(self):
        page = self.doc.load_page(self.current_page)
        zoom = 2.5  # ещё выше качество
        mat = fitz.Matrix(zoom, zoom)
        pix = page.get_pixmap(matrix=mat)
        from PyQt5.QtGui import QImage, QPixmap
        img = QImage(pix.samples, pix.width, pix.height, pix.stride, QImage.Format_RGBA8888 if pix.alpha else QImage.Format_RGB888)
        self.canvas.setPixmap(QPixmap.fromImage(img))
        self.page_label.setText(f'Стр. {self.current_page+1} / {len(self.doc)}')
        self.prev_btn.setEnabled(self.current_page > 0)
        self.next_btn.setEnabled(self.current_page < len(self.doc)-1)

    def next_page(self):
        if self.current_page < len(self.doc)-1:
            self.current_page += 1
            self.show_page()

    def prev_page(self):
        if self.current_page > 0:
            self.current_page -= 1
            self.show_page()

class StatsWindow(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Статистика продаж')
        self.resize(900, 700)
        layout = QVBoxLayout(self)
        from db import get_business_metrics, get_sales_stats, get_sales_by_date
        # Бизнес-метрики
        metrics = get_business_metrics()
        layout.addWidget(QLabel(f'Общая выручка: {metrics["total_revenue"]}'))
        layout.addWidget(QLabel(f'Продано экземпляров: {metrics["total_sales"]}'))
        layout.addWidget(QLabel(f'Средний чек: {metrics["avg_check"]:.2f}'))
        # Кнопка экспорта
        self.export_btn = QPushButton('Выгрузить в Excel')
        self.export_btn.clicked.connect(self.export_to_excel)
        layout.addWidget(self.export_btn)
        self.has_sales = metrics['total_sales'] > 0
        self.export_btn.setEnabled(self.has_sales)
        # Топ-продажи
        top = metrics['top_books']
        if top:
            top_titles = [t[0] for t in top]
            top_counts = [t[1] for t in top]
            fig1, ax1 = plt.subplots()
            ax1.bar(top_titles, top_counts)
            ax1.set_title('Топ-продаваемые книги')
            ax1.set_ylabel('Продано')
            canvas1 = FigureCanvas(fig1)
            layout.addWidget(canvas1)
        # Таблица по книгам
        stats = get_sales_stats()
        self.stats = stats
        table = QTableWidget(len(stats), 4)
        table.setHorizontalHeaderLabels(['Книга', 'Продано', 'Выручка', 'Остаток'])
        for i, (title, count, revenue, quantity) in enumerate(stats):
            table.setItem(i, 0, QTableWidgetItem(str(title)))
            table.setItem(i, 1, QTableWidgetItem(str(count or 0)))
            table.setItem(i, 2, QTableWidgetItem(str(revenue or 0)))
            table.setItem(i, 3, QTableWidgetItem(str(quantity or 0)))
        layout.addWidget(QLabel('Статистика по книгам:'))
        layout.addWidget(table)
        # График продаж по датам
        sales_by_date = get_sales_by_date()
        if sales_by_date:
            dates = [d.split('T')[0] for d, _ in sales_by_date]
            values = [v for _, v in sales_by_date]
            fig, ax = plt.subplots()
            ax.plot(dates, values, marker='o')
            ax.set_title('Выручка по дням')
            ax.set_xlabel('Дата')
            ax.set_ylabel('Сумма продаж')
            if values:
                max_value = max(values)
                ax.set_ylim(0, max_value * 1.1 if max_value > 0 else 1000)
            fig.autofmt_xdate()
            canvas = FigureCanvas(fig)
            layout.addWidget(QLabel('График продаж:'))
            layout.addWidget(canvas)

    def export_to_excel(self):
        if not self.has_sales:
            QMessageBox.warning(self, 'Экспорт невозможен', 'Нет данных о продажах для экспорта!')
            return
        path, _ = QFileDialog.getSaveFileName(self, 'Сохранить Excel', '', 'Excel Files (*.xlsx)')
        if not path:
            return
        wb = Workbook()
        ws = wb.active
        ws.title = 'Статистика продаж'
        ws.append(['Книга', 'Продано', 'Выручка', 'Остаток'])
        for row in self.stats:
            ws.append([row[0], row[1] or 0, row[2] or 0, row[3] or 0])
        wb.save(path)
        QMessageBox.information(self, 'Экспорт завершён', 'Статистика успешно сохранена в Excel!')

class AddEditBookDialog(QDialog):
    def __init__(self, parent=None, book=None):
        super().__init__(parent)
        self.setWindowTitle('Добавить/Редактировать книгу')
        self.pdf_path = ''
        layout = QFormLayout(self)

        self.title_edit = QLineEdit()
        self.author_edit = QLineEdit()
        self.genre_edit = QLineEdit()
        self.price_edit = QDoubleSpinBox()
        self.price_edit.setMaximum(1e6)
        self.quantity_edit = QDoubleSpinBox()
        self.quantity_edit.setMaximum(1e6)
        self.quantity_edit.setDecimals(0)
        self.description_edit = QTextEdit()
        self.pdf_label = QLabel('Файл не выбран')
        self.pdf_btn = QPushButton('Выбрать PDF')
        self.pdf_btn.clicked.connect(self.choose_pdf)

        layout.addRow('Название:', self.title_edit)
        layout.addRow('Автор:', self.author_edit)
        layout.addRow('Жанр:', self.genre_edit)
        layout.addRow('Цена:', self.price_edit)
        layout.addRow('Количество:', self.quantity_edit)
        layout.addRow('Описание:', self.description_edit)
        layout.addRow(self.pdf_btn, self.pdf_label)

        btns = QHBoxLayout()
        self.save_btn = QPushButton('Сохранить')
        self.save_btn.clicked.connect(self.accept)
        self.cancel_btn = QPushButton('Отмена')
        self.cancel_btn.clicked.connect(self.reject)
        btns.addWidget(self.save_btn)
        btns.addWidget(self.cancel_btn)
        layout.addRow(btns)

        if book:
            self.title_edit.setText(str(book[1]))
            self.author_edit.setText(str(book[2]))
            self.genre_edit.setText(str(book[3]))
            self.price_edit.setValue(float(book[4]))
            self.quantity_edit.setValue(int(book[5]))
            self.description_edit.setText(str(book[6]))
            self.pdf_label.setText(os.path.basename(book[7]))
            self.pdf_path = book[7]

    def choose_pdf(self):
        path, _ = QFileDialog.getOpenFileName(self, 'Выбрать PDF', '', 'PDF Files (*.pdf)')
        if path:
            self.pdf_path = path
            self.pdf_label.setText(os.path.basename(path))

    def get_data(self):
        if self.pdf_path:
            dest_path = os.path.join(PDF_DIR, os.path.basename(self.pdf_path))
            if not os.path.exists(dest_path):
                shutil.copy(self.pdf_path, dest_path)
            pdf_db_path = dest_path
        else:
            pdf_db_path = ''
        return (
            self.title_edit.text(),
            self.author_edit.text(),
            self.genre_edit.text(),
            float(self.price_edit.value()),
            int(self.quantity_edit.value()),
            self.description_edit.toPlainText(),
            pdf_db_path
        )

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Книжный магазин')
        self.resize(1100, 750)
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)

        # Универсальный фильтр по всем полям
        filter_layout = QHBoxLayout()
        self.global_filter = QLineEdit()
        self.global_filter.setPlaceholderText('Поиск по всем полям (название, автор, жанр, количество, цена, описание)')
        self.filter_btn = QPushButton('Фильтровать')
        self.filter_btn.clicked.connect(self.load_books)
        self.reset_filter_btn = QPushButton('Сбросить фильтр')
        self.reset_filter_btn.clicked.connect(self.reset_filter)
        filter_layout.addWidget(QLabel('Фильтр:'))
        filter_layout.addWidget(self.global_filter)
        filter_layout.addWidget(self.filter_btn)
        filter_layout.addWidget(self.reset_filter_btn)
        layout.addLayout(filter_layout)

        # Таблица книг
        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels(['ID', 'Название', 'Автор', 'Жанр', 'Цена', 'Количество', 'Описание'])
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.horizontalHeader().setSectionResizeMode(6, QHeaderView.Stretch)
        layout.addWidget(self.table)

        # Кнопки действий
        btn_layout = QHBoxLayout()
        self.add_btn = QPushButton('Добавить книгу')
        self.add_btn.clicked.connect(self.add_book)
        self.edit_btn = QPushButton('Редактировать')
        self.edit_btn.clicked.connect(self.edit_selected_book)
        self.del_btn = QPushButton('Удалить книгу')
        self.del_btn.clicked.connect(self.delete_selected_book)
        self.sell_btn = QPushButton('Продать книгу')
        self.sell_btn.clicked.connect(self.sell_selected_book)
        self.open_btn = QPushButton('Открыть PDF')
        self.open_btn.clicked.connect(self.open_selected_pdf)
        self.stats_btn = QPushButton('Статистика')
        self.stats_btn.clicked.connect(self.show_stats)
        btn_layout.addWidget(self.add_btn)
        btn_layout.addWidget(self.edit_btn)
        btn_layout.addWidget(self.del_btn)
        btn_layout.addWidget(self.sell_btn)
        btn_layout.addWidget(self.open_btn)
        btn_layout.addWidget(self.stats_btn)
        layout.addLayout(btn_layout)

        self.load_books()

    def load_books(self):
        filter_text = self.global_filter.text().strip().lower()
        books = get_books()
        filtered_books = []
        if filter_text:
            for book in books:
                # book: (id, title, author, genre, price, quantity, description, pdf_path)
                if any(filter_text in str(field).lower() for field in book[1:7]):
                    filtered_books.append(book)
        else:
            filtered_books = books
        self.table.setRowCount(0)
        for book in filtered_books:
            row = self.table.rowCount()
            self.table.insertRow(row)
            for col in range(7):
                self.table.setItem(row, col, QTableWidgetItem(str(book[col])))
            self.table.setRowHeight(row, 40)
        self.books = filtered_books

    def add_book(self):
        dlg = AddEditBookDialog(self)
        if dlg.exec_() == QDialog.Accepted:
            title, author, genre, price, quantity, description, pdf_path = dlg.get_data()
            if not (title and author and pdf_path):
                QMessageBox.warning(self, 'Ошибка', 'Заполните все поля и выберите PDF-файл!')
                return
            add_book(title, author, genre, price, quantity, description, pdf_path)
            self.load_books()

    def edit_selected_book(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.warning(self, 'Ошибка', 'Выберите книгу для редактирования!')
            return
        book = self.books[row]
        dlg = AddEditBookDialog(self, book)
        if dlg.exec_() == QDialog.Accepted:
            title, author, genre, price, quantity, description, pdf_path = dlg.get_data()
            update_book(book[0], title, author, genre, price, quantity, description, pdf_path)
            self.load_books()

    def delete_selected_book(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.warning(self, 'Ошибка', 'Выберите книгу для удаления!')
            return
        book_id = int(self.table.item(row, 0).text())
        reply = QMessageBox.question(self, 'Удалить', 'Удалить выбранную книгу?', QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            delete_book(book_id)
            self.load_books()

    def sell_selected_book(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.warning(self, 'Ошибка', 'Выберите книгу для продажи!')
            return
        book_id = int(self.table.item(row, 0).text())
        price = float(self.table.item(row, 4).text())
        quantity = int(self.table.item(row, 5).text())
        if quantity <= 0:
            QMessageBox.warning(self, 'Ошибка', 'Нет экземпляров для продажи!')
            return
        sell_book(book_id, price)
        QMessageBox.information(self, 'Продажа', 'Книга продана!')
        self.load_books()

    def open_selected_pdf(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.warning(self, 'Ошибка', 'Выберите книгу для просмотра!')
            return
        pdf_path = self.books[row][7]
        if not os.path.exists(pdf_path):
            QMessageBox.warning(self, 'Ошибка', 'PDF-файл не найден!')
            return
        dlg = PDFViewer(pdf_path, self)
        dlg.exec_()

    def show_stats(self):
        dlg = StatsWindow(self)
        dlg.exec_()

    def reset_filter(self):
        self.global_filter.clear()
        self.load_books() 